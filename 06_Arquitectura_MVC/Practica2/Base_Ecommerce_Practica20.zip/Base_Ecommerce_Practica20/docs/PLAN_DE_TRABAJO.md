# Actividades del equipo

1. Ejecutar la base y reconocer qué está resuelto. Registrar esta versión inicial en Git.
2. Definir el nombre y temática de la tienda y mantener al menos seis productos. Los precios se manejan en COP enteros.
3. Elaborar el modelo conceptual, esquema navegacional y especificación de interfaz abstracta de OOHDM. La implementación será la aplicación y su correspondencia con esos diseños.
4. Separar rutas, controladores, modelos, repositorios, vistas y archivos públicos. Conservar el catálogo funcional durante el cambio.
5. Implementar carrito: agregar, cambiar cantidad, eliminar y calcular total provisional.
6. Implementar el formulario de nombre/correo, el POST de pedidos y la confirmación. Aplicar las reglas en el modelo y guardar pedido y detalles en una transacción del repositorio.
7. Implementar la consulta JSON y la página de pedidos.
8. Ejecutar y documentar los casos de aceptación de la guía. Revisar desde una copia limpia del repositorio.
9. Completar README, diseños, evidencia de pruebas y aportes de ambos integrantes.
10. Preparar sustentación presencial de mínimo 10 minutos y preguntas sobre todo el sistema. La calificación es grupal.

Las funciones leerJson y enTransaccion son apoyos suministrados. Reubicarlas según su responsabilidad. El esquema SQL se entrega para concentrar el trabajo en la aplicación. Las carpetas finales deben reflejar responsabilidades reales.

Entregar documentación en docs/: diseño OOHDM, arquitectura, pruebas y aportes. No se proporciona una solución final de carrito o pedidos.
